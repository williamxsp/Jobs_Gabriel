//////////////////////
// Help File //
//////////////////////

//////////////////////
// Release date: 17-08-2014 (08-17-2014)
// Version 0.1 //
//////////////////////

Thanks for you downloading EdgeSlotMachine by Chris Gannon.

Required and included files:

===================================================================================================

* EdgeSlotMachine.antmpl
* js/greensock/minified/TweenMax.min.js
* js/greensock/minified/utils/Draggable.min.js
* js/greensock/minified/plugins/ScrambleTextPlugin.min.js
* js/greensock/minified/plugins/TextPlugin.min.js

===================================================================================================

**Notice**

This file uses Greensock's (paid) ThrowPropsPlugin which is included in this package. You may use this plugin with EdgeSlotMachine only. It is not redistributable and can't be used on other projects that don't include it.


===================================================================================================


FEATURES:

* Customize messages, spins and more in an external JSON file
* Customize your slot images
* Customize the entire look and feel
* Ability to control when to win and lose
* Touch and mouse input
* Unique one-armed-bandit 'pull' interaction
* Scalable/responsive and remains centered
* Optimized for desktop AND mobile
* All graphics supplied as vectors in a Flash file

Greensock's TweenMax is used for maximum control, flexibility and performance.

- To open the project launch Adobe Edge Animate and select 'Create from Template' and navigate to EdgeSlotMachine.antmpl.
- Create a folder and immediately save the new project - this will unpack the template into that folder.

Next copy the supplied JS folder into the project's root folder

===================================================================================================


In the 'compositionReady' event there is well commented code. I recommend using an external code editor like SublimeText - it's brilliant and free (with nags) http://www.sublimetext.com/3


===================================================================================================


======================================JSON data explained==========================================

You will mainly want to make edits to preferences (like number of spins allowed) in the data.json file

@initialSpinCount - this is the number of spins a player can have

@imagePath - the path to your images

@message[0-7] - the messages that are displayed when you spin or nudge or win/lose

@numFaces - this must be bigger than the number of slot images. If you use a large number (say 100) the likelihood of a winning line is seriously reduced. However this has a performance overhead. I would suggest using no more than twice the number of slot images you have. This will still be produce totally random result.

@faceWidth - the width of your slot images

@faceHeight - the height of your slot images

===================================================================================================


* To add a new slot image

- Create the new PNG image - ensure it has a transparent background. In this example we'll create a new slot image called orange.png
- Open data.json. In it you'll see an array of objects called 'imageObjectsArray'.

An entry looks like this:

	{"image":"bar", "value":750}

- Add a new entry (or edit an existing one) using just the file name and NOT the extension. 
- Add a win value for it (can be anything).

Our new JSON might look like this:

	{"image":"bar", "value":750},
	{"image":"orange", "value":325}



* To remove an existing slot image

Simply delete the object entry in the array for that slot image - if you delete the last one in the array make sure that you delete the , (comma) from the entry that has now become the last one (the one that was above it).

* To produce a win (3 in a row)

In the code find the function 'armDragEnd' - this is called when you drag then release the arm.

In it you will see it's calling spin(); 
Currently it's not sending an argument to spin(); which means it will generate a random spin result.

To generate a win you must send a value between 0 and the length of imageObjectsArray. 

With the current JSON as it is, if you want to make a user win three bars you call spin(0); because 'bar' is at position 0 in imageObjectsArray. 
Similarly if you want to force a win of 3 sevens you would call spin(5); because 5 is the position of 'seven' in the imageObjectsArray. Ya feel me?

The way it's set up means you could easily hook this up to a backend to control wins and loses.




===================================================================================================

You are free to edit practically anything graphically. I created the graphics on Flash so I have included a Flash FLA file with some graphics in.


===================================================================================================



I hope you enjoy using this and if you like it and/or find it useful then please remember to rate it (and/or me) - thanks!

**Chris Gannon - August 2014**